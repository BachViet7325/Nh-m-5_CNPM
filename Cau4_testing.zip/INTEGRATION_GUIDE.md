# 🎯 Hướng dẫn Sử dụng Hệ thống Quản lý Lịch Họp v2.0 (MySQL)

## 📋 Giới thiệu

Hệ thống Quản lý Lịch Họp phiên bản 2.0 đã được hoàn toàn tích hợp với MySQL. Tất cả dữ liệu được lưu trữ an toàn trong cơ sở dữ liệu thay vì tệp SQLite cũ.

---

## ⚡ Chuẩn bị (5 phút)

### 1. Kiểm tra MySQL Server

Đảm bảo MySQL Server đang chạy:
```bash
mysql -u root
```

Hoặc chạy MySQL từ Services (Windows):
- Nhấn `Win + R`, gõ `services.msc`
- Tìm `MySQL80` (hoặc phiên bản MySQL của bạn)
- Nhấp chuột phải → `Start`

### 2. Tạo Database

Từ Command Prompt/Terminal, chạy:
```bash
cd c:\Users\admin\Downloads\cau4_coding_Tuan2\cau4_meeting_module\cau4_meeting_module
mysql -u root < database.sql
```

✅ Khi xong, bạn sẽ thấy dữ liệu mẫu được import tự động.

### 3. Cài đặt Dependencies

```bash
npm install
```

### 4. Khởi động Server

```bash
npm start
```

Bạn sẽ thấy:
```
🚀 Hệ thống quản lý lịch họp chạy tại: http://localhost:3000
```

✅ Server đang chạy! Mở trình duyệt và truy cập.

---

## 🌐 Giao diện Người dùng

### 🏠 Trang Chủ
- URL: http://localhost:3000/Home.html
- Chọn vai trò: Nhân viên, Quản lý, hoặc Admin

### 👨‍💼 Giao diện Nhân viên (index.html)

#### Xem Lịch Họp
1. Bộ lọc:
   - **Từ ngày** - Ngày bắt đầu
   - **Đến ngày** - Ngày kết thúc
   - **Trạng thái** - Tất cả, Đã lên lịch, Đã hủy
   - Nhấp **Lọc** để xem kết quả

2. Bảng Lịch Họp:
   - Hiển thị: Thời gian, Tên cuộc họp, Phòng, Người tham gia, Trạng thái
   - Thao tác: Xóa lịch họp

#### Tạo Lịch Họp Mới
1. Điền biểu mẫu:
   - **Tên cuộc họp (*)** - Tiêu đề cuộc họp
   - **Ngày họp (*)** - Chọn ngày từ lịch
   - **Giờ bắt đầu (*)** - Giờ bắt đầu (HH:MM)
   - **Giờ kết thúc (*)** - Giờ kết thúc (HH:MM)
   - **Phòng họp (*)** - Chọn từ dropdown
   - **Người tham gia (*)** - Chọn 1+ người (Shift+Click chọn nhiều)
   - **Nội dung** - Ghi chú thêm

2. Nhấp **Kiểm tra lịch** để xác minh:
   - Phòng không trùng lịch
   - Người tham gia không trùng lịch

3. Nhấp **Lưu lịch họp** để lưu vào database

4. Lịch sẽ xuất hiện trong bảng phía trên sau khi lưu thành công

### 🧑‍💼 Giao diện Quản lý (manager.html)

#### Danh sách Phòng Họp
- Hiển thị tất cả phòng trong hệ thống
- Thông tin: Tên phòng, Sức chứa, Vị trí, Tổng cuộc họp
- Thao tác: Chi tiết phòng

#### Lịch Họp Hôm Nay
- Hiển thị tất cả cuộc họp trong ngày hôm nay
- Thông tin: Thời gian, Tên họp, Phòng, Người tham gia

### 🛡️ Giao diện Admin (admin.html)

#### Quản lý Nhân viên
1. **Biểu mẫu Thêm/Sửa Nhân viên**:
   - Họ tên (*)
   - Email (*)
   - Vai trò (Phòng ban)
   
2. **Bảng Nhân viên**:
   - Hiển thị tất cả nhân viên
   - Thao tác: Sửa, Xóa

#### Quản lý Phòng Họp
1. **Biểu mẫu Thêm/Sửa Phòng**:
   - Tên phòng (*)
   - Sức chứa (*)
   - Trạng thái phòng
   - Thiết bị
   
2. **Bảng Phòng Họp**:
   - Hiển thị tất cả phòng
   - Thao tác: Sửa, Xóa

#### Thống kê
- Tổng nhân viên
- Nhân viên hoạt động
- Tổng lịch họp
- Phòng họp trống

---

## 📊 API Endpoints

### Phòng Họp
```
GET    /api/rooms              → Lấy danh sách phòng
POST   /api/rooms              → Thêm phòng
PUT    /api/rooms/:id          → Cập nhật phòng
DELETE /api/rooms/:id          → Xóa phòng
```

### Nhân Viên
```
GET    /api/users              → Lấy danh sách nhân viên
POST   /api/users              → Thêm nhân viên
PUT    /api/users/:id          → Cập nhật nhân viên
DELETE /api/users/:id          → Xóa nhân viên
```

### Lịch Họp
```
GET    /api/meetings           → Lấy danh sách lịch
POST   /api/meetings           → Tạo lịch họp
POST   /api/meetings/check     → Kiểm tra xung đột
DELETE /api/meetings/:id       → Xóa lịch họp
```

### Thống kê
```
GET    /api/admin/stats        → Lấy thống kê
```

---

## 🔧 Cấu hình MySQL

Mở file `server.js` và tìm section cấu hình:

```javascript
const pool = mysql.createPool({
  host: 'localhost',              // Địa chỉ server (127.0.0.1)
  user: 'root',                   // Tên user MySQL
  password: '',                   // Mật khẩu (nếu có)
  database: 'quanlylichhop',      // Tên database
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});
```

### Nếu MySQL có mật khẩu:
```javascript
password: 'your_password',
```

### Nếu MySQL ở server khác:
```javascript
host: '192.168.1.100',
```

---

## ✅ Kiểm tra Hoạt động

### Test Phòng Họp
1. Vào Admin → Thêm phòng mới
2. Vào Nhân viên → Xem phòng mới xuất hiện trong dropdown

### Test Nhân viên
1. Vào Admin → Thêm nhân viên mới
2. Vào Nhân viên → Xem nhân viên mới trong danh sách người tham gia

### Test Lịch Họp
1. Vào Nhân viên → Tạo lịch mới
2. Kiểm tra lịch → Nên thành công (nếu không xung đột)
3. Lưu lịch → Hiển thị trong bảng
4. Xóa lịch → Lịch bị xóa khỏi database

### Test Xung Đột
1. Tạo lịch A: Phòng 1, 9:00-10:00
2. Tạo lịch B: Cùng phòng, 9:30-10:30
3. Kiểm tra lịch B → Sẽ báo "Phòng bị trùng lịch"

---

## 🐛 Xử lý Sự Cố

### Lỗi: "Cannot find module mysql2"
```bash
npm install mysql2
```

### Lỗi: "Access denied for user 'root'@'localhost'"
- Mật khẩu MySQL sai
- Cập nhật `server.js`: `password: 'correct_password'`

### Lỗi: "Unknown database 'quanlylichhop'"
```bash
mysql -u root < database.sql
```

### Lỗi: "EADDRINUSE :::3000"
- Port 3000 đang sử dụng
- Đóng server cũ: `Ctrl+C`
- Hoặc thay đổi port trong `server.js`

### Giao diện trống / Không tải dữ liệu
- Kiểm tra console browser: `F12` → Tab Console
- Kiểm tra server logs: `npm start`
- Đảm bảo MySQL Server đang chạy

---

## 📞 Hỗ trợ

- Nếu gặp lỗi, kiểm tra:
  1. MySQL Server có chạy?
  2. Database `quanlylichhop` có tồn tại?
  3. Server Node.js có chạy?
  4. Port 3000 có trống?

---

## 🎉 Hoàn thành!

Hệ thống Quản lý Lịch Họp v2.0 đã sẵn sàng sử dụng!
