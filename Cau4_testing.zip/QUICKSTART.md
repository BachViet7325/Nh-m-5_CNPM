# 🚀 HƯỚNG DẪN NHANH - BẮT ĐẦU HỆ THỐNG

## ⚡ Cài đặt Nhanh (5 phút)

### 1️⃣ Cài đặt MySQL
- Tải từ: https://dev.mysql.com/downloads/mysql/
- Chọn phiên bản phù hợp (MySQL 5.7+ hoặc 8.0)
- Cài đặt với User: `root`, Password: (để trống hoặc nhớ mật khẩu)

### 2️⃣ Cài đặt Node.js
- Tải từ: https://nodejs.org/ (LTS)
- Cài đặt mặc định

### 3️⃣ Tạo Database
Mở Command Prompt/Terminal và chạy:

```bash
cd c:\Users\admin\Downloads\cau4_coding_Tuan2\cau4_meeting_module\cau4_meeting_module
mysql -u root -p < database.sql
```

Nếu MySQL không có mật khẩu, bỏ qua phần `-p`:
```bash
mysql -u root < database.sql
```

### 4️⃣ Cài Dependencies
```bash
npm install
```

### 5️⃣ Chạy Server
```bash
npm start
```

Kết quả:
```
🚀 Hệ thống quản lý lịch họp chạy tại: http://localhost:3000
```

### 6️⃣ Mở Trình Duyệt
```
http://localhost:3000/Home.html
```

---

## 🔑 Tài Khoản Mẫu

Hệ thống đã được tạo sẵn với dữ liệu mẫu:

| Vai Trò | Người | Email |
|---------|-------|-------|
| IT | Nguyen Van An | an@gmail.com |
| HR | Tran Thi Binh | binh@gmail.com |
| Kế Toán | Le Minh Cuong | cuong@gmail.com |
| Kinh Doanh | Pham Quoc Dung | dung@gmail.com |
| Marketing | Hoang Thi Lan | lan@gmail.com |

---

## 📍 Truy Cập Các Trang

| Trang | URL |
|------|-----|
| 🏠 Trang Chủ | http://localhost:3000/Home.html |
| 👤 Nhân Viên | http://localhost:3000/index.html |
| 👨‍💼 Quản Lý | http://localhost:3000/manager.html |
| 🔐 Admin | http://localhost:3000/admin.html |

---

## 📋 Các Chức Năng Chính

### Nhân Viên
- ✅ Xem lịch họp
- ✅ Tạo cuộc họp mới
- ✅ Chọn phòng và người tham gia
- ✅ Quản lý lịch họp

### Admin
- ✅ Quản lý người dùng (thêm, sửa, khóa)
- ✅ Quản lý phòng họp
- ✅ Xem thống kê hệ thống
- ✅ Theo dõi hoạt động

### Quản Lý Phòng
- ✅ Xem danh sách phòng
- ✅ Quản lý trạng thái phòng
- ✅ Theo dõi lịch sử sử dụng

---

## 🆘 Xử Lý Sự Cố

### ❌ Lỗi: "Cannot find module 'mysql2'"
```bash
npm install mysql2
```

### ❌ Lỗi: "Access denied for user 'root'@'localhost'"
Bạn cần nhập mật khẩu MySQL:
```bash
mysql -u root -p < database.sql
```

Khi nhập lệnh, hãy gõ mật khẩu MySQL của bạn (nếu có) và nhấn Enter.

### ❌ Lỗi: "Unknown database 'quanlylichhop'"
```bash
mysql -u root -p < database.sql
```

### ❌ Lỗi: "Port 3000 already in use"
Một server khác đang dùng port 3000. Chọn một trong:
1. Đóng ứng dụng khác sử dụng port 3000
2. Thay đổi PORT trong `server.js` thành số khác (3001, 3002...)

### ❌ Lỗi: "Cannot GET /Home.html"
- Đảm bảo bạn đang ở folder đúng
- Restart server (`npm start`)

---

## 🔧 Cấu Hình MySQL

Nếu MySQL của bạn có mật khẩu, mở `server.js` và sửa:

```javascript
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'YOUR_PASSWORD',  // ← Thay mật khẩu ở đây
  database: 'quanlylichhop',
  // ...
});
```

Sau đó restart server.

---

## 📊 Kiểm Tra Database

Để xem các bảng đã tạo:
```bash
mysql -u root -p quanlylichhop
mysql> SHOW TABLES;
mysql> SELECT * FROM phonghop;
mysql> SELECT * FROM nhanvien;
mysql> SELECT * FROM lichhop;
```

---

## 💡 Mẹo

1. **Luôn chắc chắn MySQL Server đang chạy** trước khi start server
2. **Giữ command prompt/terminal mở** khi chạy server
3. **Không đóng cửa sổ terminal**, nó sẽ dừng server
4. Để **dừng server**, nhấn `Ctrl + C` trong terminal

---

## 🎓 Học Thêm

- 📚 [Express.js Documentation](https://expressjs.com/)
- 🗄️ [MySQL Documentation](https://dev.mysql.com/doc/)
- 🌐 [MDN Web Docs](https://developer.mozilla.org/)

---

Nếu gặp vấn đề, kiểm tra lại:
1. ✅ MySQL Server có chạy không?
2. ✅ Node.js đã cài đặt chưa?
3. ✅ Database đã tạo chưa?
4. ✅ Dependencies đã cài (`npm install`) chưa?
