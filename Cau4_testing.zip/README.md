# Câu 4 - Coding Module Nhân viên: Tạo lịch họp mới và quản lý cuộc họp

Dự án hệ thống quản lý lịch họp cho nhân viên, quản lý phòng họp và admin.

## Công nghệ
- Frontend: HTML, CSS, JavaScript
- Backend: Node.js + Express
- CSDL: MySQL

## Cách chạy

### 1. Cài đặt Dependencies
```bash
npm install
```

### 2. Tạo Database
```bash
mysql -u root -p < database.sql
```

### 3. Chạy Server
```bash
npm start
```

### 4. Truy cập Giao diện
- **Trang chủ**: http://localhost:3000/Home.html
- **Nhân viên**: http://localhost:3000/index.html
- **Admin**: http://localhost:3000/admin.html
- **Quản lý**: http://localhost:3000/manager.html

## Chức năng đã hoàn thành
1. Xem/quản lý danh sách lịch họp
   - Lọc theo từ ngày, đến ngày, trạng thái.
   - Hiển thị thời gian, tên cuộc họp, phòng, người tham gia, trạng thái.
   - Hủy cuộc họp.
   - Xóa cuộc họp.

2. Tạo lịch họp mới
   - Nhập tên cuộc họp.
   - Chọn ngày họp.
   - Chọn giờ bắt đầu và giờ kết thúc.
   - Chọn phòng họp.
   - Chọn nhiều người tham gia.
   - Nhập nội dung cuộc họp.
   - Kiểm tra lịch trước khi lưu.

## Ràng buộc nghiệp vụ
- Tên cuộc họp bắt buộc, tối đa 100 ký tự.
- Ngày họp không được nhỏ hơn ngày hiện tại.
- Giờ kết thúc phải lớn hơn giờ bắt đầu.
- Bắt buộc chọn phòng họp.
- Bắt buộc chọn tối thiểu 1 người tham gia.
- Không lưu nếu phòng bị trùng lịch.
- Không lưu nếu người tham gia bị trùng lịch.
- Hủy cuộc họp sẽ cập nhật trạng thái thành “Đã hủy”.
