# Phiên bản hoàn thiện theo gợi ý đề bài

## Nhân viên
- Đăng nhập, cập nhật hồ sơ, đổi mật khẩu.
- Xem lịch theo ngày/tuần/tháng.
- Lọc theo khoảng ngày, phòng, người tổ chức, trạng thái.
- Tạo/sửa/hủy cuộc họp; kiểm tra phòng và người tham gia bận.
- Người được mời có thể Đồng ý hoặc Từ chối.

## Quản lý phòng họp
- Thêm, sửa, xóa/xử lý ngừng sử dụng phòng.
- Quản lý vị trí, sức chứa, thiết bị, trạng thái phòng.
- Xem lịch sử sử dụng và số giờ.
- Xem khung giờ trống theo ngày.

## Administrator
- Tạo, khóa, phân quyền tài khoản.
- Dashboard số cuộc họp theo tháng.
- Thống kê số giờ sử dụng phòng và người tổ chức nhiều cuộc họp.
- Bộ lọc ngày áp dụng đồng bộ cho thống kê.

## Tài khoản mẫu
- Admin: admin@xyz.com / Admin@123
- Tài khoản do Admin tạo mặc định: Temp@123 (nếu không nhập mật khẩu)

## Chạy
1. Bật MySQL.
2. `npm install`
3. `npm start`
4. Mở http://localhost:3000/login.html
