# Bản hoàn thiện đồ án quản lý cuộc họp

## Chạy dự án
```powershell
npm install
npm start
```
Mở `http://localhost:3000/login.html`.

## Tài khoản quản trị mặc định
- Email: `admin@xyz.com`
- Mật khẩu: `Admin@123`

Hãy đổi mật khẩu mặc định trước khi triển khai thực tế.

## Các chức năng đã hoàn thiện
- Đăng ký công khai chỉ tạo vai trò Nhân viên.
- Đăng nhập bằng token phiên; tất cả API nghiệp vụ yêu cầu đăng nhập.
- Backend phân quyền Nhân viên, Quản lý và Admin.
- Nhân viên chỉ xem lịch có mình tham gia; Quản lý xem dữ liệu phòng ban; Admin xem toàn hệ thống.
- Chủ trì được sửa/hủy cuộc họp; chỉ Admin được xóa vĩnh viễn.
- Kiểm tra trùng phòng và trùng người, bỏ qua lịch đã hủy và loại trừ lịch đang sửa.
- Kiểm tra sức chứa, người dùng bị khóa, dữ liệu ngày giờ, email và số nguyên dương.
- Thống kê scheduled/completed/cancelled, số giờ sử dụng phòng và top người tổ chức.
- Khóa mềm tài khoản để giữ lịch sử thay vì xóa cứng.
- Index database cho truy vấn lịch theo phòng, thời gian và người tham gia.

## Cấu hình MySQL tùy chọn
```powershell
$env:DB_USER="root"
$env:DB_PASSWORD="mat_khau"
$env:DB_HOST="127.0.0.1"
$env:DB_PORT="3306"
npm start
```
