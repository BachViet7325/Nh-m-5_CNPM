# Hướng dẫn Setup - Hệ thống Quản lý Lịch Họp

## 📋 Yêu cầu

- Node.js (v14+)
- MySQL Server (v5.7+)
- npm

## 🚀 Bước 1: Cài đặt Dependencies

```bash
npm install
```

## 🗄️ Bước 2: Tạo Database MySQL

### Cách 1: Sử dụng MySQL Command Line
```bash
mysql -u root -p < database.sql
```

### Cách 2: Sử dụng MySQL Workbench
1. Mở MySQL Workbench
2. Tạo kết nối đến MySQL Server
3. Mở file `database.sql`
4. Thực thi script

### Cách 3: Sử dụng MySQL Client
```bash
mysql -u root
mysql> source database.sql;
```

## ⚙️ Bước 3: Cấu hình Kết nối

Mở file `server.js` và kiểm tra thông tin kết nối MySQL:

```javascript
const pool = mysql.createPool({
  host: 'localhost',      // Địa chỉ MySQL Server
  user: 'root',           // Tên người dùng MySQL
  password: '',           // Mật khẩu (để trống nếu không có)
  database: 'quanlylichhop',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});
```

Nếu MySQL của bạn có mật khẩu, thay đổi dòng:
```javascript
password: 'your_password',  // Thay 'your_password' bằng mật khẩu của bạn
```

## ▶️ Bước 4: Chạy Server

```bash
npm start
```

Hoặc:
```bash
node server.js
```

Khi thành công, bạn sẽ thấy:
```
🚀 Hệ thống quản lý lịch họp chạy tại: http://localhost:3000
📊 Ghi chú: Đảm bảo MySQL Server đang chạy và database 'quanlylichhop' đã được tạo.
💾 Để import database, chạy: mysql -u root < database.sql
```

## 🌐 Bước 5: Truy cập Giao diện

Mở trình duyệt và truy cập:
- **Trang chủ**: http://localhost:3000/Home.html
- **Nhân viên**: http://localhost:3000/index.html
- **Admin**: http://localhost:3000/admin.html
- **Quản lý**: http://localhost:3000/manager.html

## 📊 Dữ liệu Mẫu

Database đã được tạo với dữ liệu mẫu:

### Phòng Họp
- Phong A101 (Tầng 1, 20 người)
- Phong B201 (Tầng 2, 15 người)
- Phong C301 (Tầng 3, 10 người)

### Nhân Viên
- Nguyen Van An (IT)
- Tran Thi Binh (Nhân sự)
- Le Minh Cuong (Kế toán)
- Pham Quoc Dung (Kinh doanh)
- Hoang Thi Lan (Marketing)

### Lịch Họp Mẫu
- 15/07/2026: Họp Dự án Website (Phòng A, 08:00-10:00)
- 16/07/2026: Họp Kế Hoạch Quý 3 (Phòng B, 14:00-15:30)
- 17/07/2026: Họp Tổng Kết (Phòng C, 09:00-11:00)

## 🔍 API Endpoints

### Phòng Họp
- `GET /api/rooms` - Lấy danh sách phòng
- `POST /api/rooms` - Thêm phòng mới

### Nhân Viên
- `GET /api/users` - Lấy danh sách nhân viên
- `POST /api/users` - Thêm nhân viên mới

### Lịch Họp
- `GET /api/meetings` - Lấy danh sách cuộc họp
- `POST /api/meetings` - Tạo cuộc họp mới
- `POST /api/meetings/check` - Kiểm tra lịch trước khi tạo
- `DELETE /api/meetings/:id` - Xóa cuộc họp

### Admin
- `GET /api/admin/stats` - Lấy thống kê hệ thống

## 🐛 Khắc phục Sự cố

### Lỗi: Cannot find module 'mysql2'
```bash
npm install mysql2
```

### Lỗi: Access denied for user 'root'@'localhost'
- Kiểm tra MySQL đang chạy
- Kiểm tra mật khẩu trong `server.js`
- Chạy MySQL với user có quyền

### Lỗi: Unknown database 'quanlylichhop'
```bash
mysql -u root -p < database.sql
```

### Lỗi: Cannot GET /Home.html
- Đảm bảo file HTML tồn tại trong folder `public/`
- Restart server

## 📝 Ghi Chú

- Database tự động tạo khi server khởi động lần đầu
- Dữ liệu sẽ được lưu trữ trong MySQL Server
- Không cần xóa database để reset, chỉ cần clear dữ liệu

## 🆘 Cần Giúp?

- Kiểm tra MySQL Server có chạy không
- Kiểm tra port 3000 có sẵn không
- Xem logs của Node.js để tìm lỗi cụ thể
