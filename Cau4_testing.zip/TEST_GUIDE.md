# � HƯỚNG DẪN KIỂM TRA TOÀN BỘ - Phiên bản v2.0 (MySQL)

## ✅ Các Thay Đổi Đã Hoàn Thành

### 1. **Backend (server.js)**
- ✅ Kết nối MySQL thực tế với connection pooling
- ✅ API Endpoints:
  - **Rooms**: GET, POST, PUT, DELETE
  - **Users**: GET, POST, PUT, DELETE
  - **Meetings**: GET (with filters), POST, DELETE
  - **Validation**: POST /api/meetings/check với kiểm tra xung đột
  - **Admin**: GET /api/admin/stats

### 2. **Frontend - admin.js** (Quản lý Admin)
- ✅ Tải toàn bộ dữ liệu từ MySQL
- ✅ Thêm/Sửa/Xóa nhân viên → Database
- ✅ Thêm/Sửa/Xóa phòng → Database
- ✅ Xem thống kê: Tổng nhân viên, phòng, cuộc họp

### 3. **Frontend - app.js** (Giao diện Nhân viên)
- ✅ Tải phòng và nhân viên từ MySQL
- ✅ Tạo lịch họp với kiểm tra xung đột
- ✅ Xem lịch họp với bộ lọc (ngày, trạng thái)
- ✅ Xóa lịch họp

### 4. **Frontend - manager.js** (Giao diện Quản lý)
- ✅ Hiển thị danh sách phòng họp
- ✅ Hiển thị lịch họp hôm nay
- ✅ Xem số lượng cuộc họp

---

## 🚀 Cách Chạy & Kiểm Tra

### Bước 1: Chuẩn Bị
```bash
# Cài đặt MySQL
# Import database
mysql -u root < database.sql

# Cài npm packages
npm install
```

### Bước 2: Chạy Server
```bash
npm start
```

Kết quả mong đợi:
```
🚀 Hệ thống quản lý lịch họp chạy tại: http://localhost:3000
```

### Bước 3: Kiểm Tra Giao Diện Admin

1. **Mở trình duyệt**: http://localhost:3000/admin.html

2. **Kiểm tra Phần Quản Lý Nhân Viên**:
   - [ ] Bảng nhân viên hiển thị dữ liệu từ database (5 nhân viên)
   - [ ] Nhấn nút "Sửa" để chỉnh sửa thông tin
   - [ ] Nhấn nút "Xóa" để xóa nhân viên
   - [ ] Điền form và nhấn "Lưu tài khoản" để thêm nhân viên mới
   - [ ] Kiểm tra thông báo thành công/lỗi

3. **Kiểm tra Phần Quản Lý Phòng Họp**:
   - [ ] Bảng phòng hiển thị dữ liệu từ database (3 phòng)
   - [ ] Nhấn nút "Sửa" để chỉnh sửa thông tin
   - [ ] Nhấn nút "Xóa" để xóa phòng
   - [ ] Điền form và nhấn "Lưu phòng họp" để thêm phòng mới
   - [ ] Kiểm tra thông báo thành công/lỗi

4. **Kiểm tra Thống Kê**:
   - [ ] Tổng số người dùng cập nhật
   - [ ] Tổng số phòng cập nhật
   - [ ] Biểu đồ hiệu suất phòng

---

## 🧪 Test Cases

### Test Thêm Nhân Viên
```
1. Điền Họ và tên: "Trần Văn A"
2. Điền Email: "trana@gmail.com"
3. Chọn Vai trò: "IT"
4. Nhấn "Lưu tài khoản"
✓ Thành công: "Đã thêm tài khoản mới."
✓ Bảng cập nhật tức thì
```

### Test Sửa Nhân Viên
```
1. Nhấn nút "Sửa" ở nhân viên muốn sửa
2. Thay đổi thông tin
3. Nhấn "Lưu tài khoản"
✓ Thành công: "Đã cập nhật thông tin người dùng."
✓ Bảng cập nhật tức thì
```

### Test Xóa Nhân Viên
```
1. Nhấn nút "Xóa" ở nhân viên muốn xóa
2. Xác nhận trong dialog
✓ Thành công: "Đã xóa người dùng."
✓ Bảng cập nhật tức thì
```

### Test Thêm Phòng Họp
```
1. Điền Tên phòng: "Phòng D"
2. Điền Sức chứa: "10"
3. Nhấn "Lưu phòng họp"
✓ Thành công: "Đã thêm phòng họp mới."
✓ Bảng cập nhật tức thì
```

---

## 📊 Kiểm Tra Database

Để xem dữ liệu trực tiếp trong database:

```bash
# Mở MySQL
mysql -u root quanlylichhop

# Xem nhân viên
mysql> SELECT * FROM nhanvien;

# Xem phòng
mysql> SELECT * FROM phonghop;

# Xem lịch họp
mysql> SELECT * FROM lichhop;

# Xem người tham gia
mysql> SELECT * FROM thamgiahop;
```

---

## 🔍 Xử Lý Sự Cố

### ❌ Lỗi: Không thể kết nối MySQL
```
✓ Kiểm tra MySQL Server đã chạy?
✓ Kiểm tra database 'quanlylichhop' đã tạo?
✓ Kiểm tra mật khẩu trong server.js
```

### ❌ Lỗi: API trả về lỗi
```
✓ Mở DevTools (F12) → Console
✓ Kiểm tra error message
✓ Kiểm tra Network tab → API requests
```

### ❌ Lỗi: Dữ liệu không cập nhật
```
✓ Refresh trang (F5)
✓ Xóa cache (Ctrl + Shift + Delete)
✓ Restart server (Ctrl + C rồi npm start)
```

---

## 📱 API Endpoints Sử Dụng

### Nhân Viên
| Phương | Endpoint | Mục Đích |
|--------|----------|---------|
| GET | `/api/users` | Lấy danh sách nhân viên |
| POST | `/api/users` | Thêm nhân viên mới |
| PUT | `/api/users/:id` | Cập nhật nhân viên |
| DELETE | `/api/users/:id` | Xóa nhân viên |

### Phòng Họp
| Phương | Endpoint | Mục Đích |
|--------|----------|---------|
| GET | `/api/rooms` | Lấy danh sách phòng |
| POST | `/api/rooms` | Thêm phòng mới |
| PUT | `/api/rooms/:id` | Cập nhật phòng |
| DELETE | `/api/rooms/:id` | Xóa phòng |

### Lịch Họp
| Phương | Endpoint | Mục Đích |
|--------|----------|---------|
| GET | `/api/meetings` | Lấy danh sách cuộc họp |
| POST | `/api/meetings` | Tạo cuộc họp mới |
| DELETE | `/api/meetings/:id` | Xóa cuộc họp |

---

## 💾 Dữ Liệu Mẫu Ban Đầu

### Nhân Viên
- Nguyen Van An (IT)
- Tran Thi Binh (Nhan su)
- Le Minh Cuong (Ke toan)
- Pham Quoc Dung (Kinh doanh)
- Hoang Thi Lan (Marketing)

### Phòng Họp
- Phong A101 (20 người)
- Phong B201 (15 người)
- Phong C301 (10 người)

---

## ✨ Tính Năng Đã Hoàn Thành

✅ **Lấy dữ liệu từ MySQL**
- Nhân viên
- Phòng họp
- Lịch họp

✅ **Tạo dữ liệu**
- Thêm nhân viên mới
- Thêm phòng họp mới
- Tạo lịch họp mới

✅ **Cập nhật dữ liệu**
- Sửa thông tin nhân viên
- Sửa thông tin phòng
- Cập nhật lịch họp

✅ **Xóa dữ liệu**
- Xóa nhân viên
- Xóa phòng
- Xóa lịch họp

✅ **Xử lý lỗi**
- Thông báo lỗi rõ ràng
- Validation dữ liệu
- Error handling toàn diện

---

## 🎯 Kết Luận

Hệ thống web đã được kết nối hoàn toàn với MySQL database. Tất cả dữ liệu được lưu trữ thực tế trong database thay vì dữ liệu mock. Người dùng có thể:

1. ✅ Xem dữ liệu từ database
2. ✅ Tạo dữ liệu mới và lưu vào database
3. ✅ Cập nhật dữ liệu hiện có
4. ✅ Xóa dữ liệu không cần thiết
5. ✅ Nhận thông báo lỗi/thành công

Toàn bộ hệ thống đã sẵn sàng để sử dụng! 🚀
