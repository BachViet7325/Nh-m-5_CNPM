-- ==========================
-- TẠO DATABASE
-- ==========================
CREATE DATABASE IF NOT EXISTS quanlylichhop;
USE quanlylichhop;

-- ==========================
-- BẢNG PHÒNG HỌP
-- ==========================
CREATE TABLE phonghop (
    maPhong INT AUTO_INCREMENT PRIMARY KEY,
    tenPhong VARCHAR(100) NOT NULL,
    viTri VARCHAR(100),
    sucChua INT NOT NULL,
    trangThai VARCHAR(20) NOT NULL DEFAULT 'available',
    thietBi TEXT
);

-- ==========================
-- BẢNG NHÂN VIÊN
-- ==========================
CREATE TABLE nhanvien (
    maNV INT AUTO_INCREMENT PRIMARY KEY,
    hoTen VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    phongBan VARCHAR(100),
    matKhau VARCHAR(255),
    vaiTroHeThong VARCHAR(30) NOT NULL DEFAULT 'Nhan vien',
    trangThai VARCHAR(20) NOT NULL DEFAULT 'active'
);

-- ==========================
-- BẢNG LỊCH HỌP
-- ==========================
CREATE TABLE lichhop (
    maHop INT AUTO_INCREMENT PRIMARY KEY,
    tieuDe VARCHAR(200) NOT NULL,
    maPhong INT NOT NULL,
    gioBatDau DATETIME NOT NULL,
    gioKetThuc DATETIME NOT NULL,
    noiDung TEXT,
    trangThai VARCHAR(20) NOT NULL DEFAULT 'scheduled',

    FOREIGN KEY (maPhong)
    REFERENCES phonghop(maPhong)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
);

-- ==========================
-- BẢNG NHÂN VIÊN THAM GIA
-- ==========================
CREATE TABLE thamgiahop (
    maHop INT,
    maNV INT,
    vaiTro VARCHAR(50) DEFAULT 'Thanh vien',
    trangThaiThamGia VARCHAR(20) NOT NULL DEFAULT 'pending',

    PRIMARY KEY (maHop, maNV),

    FOREIGN KEY (maHop)
    REFERENCES lichhop(maHop)
    ON DELETE CASCADE
    ON UPDATE CASCADE,

    FOREIGN KEY (maNV)
    REFERENCES nhanvien(maNV)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

-- ==========================
-- THÊM PHÒNG HỌP
-- ==========================
INSERT INTO phonghop (tenPhong, viTri, sucChua, trangThai, thietBi) VALUES
('Phong A101', 'Tang 1', 20, 'available', 'Máy chiếu, Camera, Micro'),
('Phong B201', 'Tang 2', 15, 'available', 'Máy chiếu, TV'),
('Phong C301', 'Tang 3', 10, 'maintenance', 'Camera, Micro');

-- ==========================
-- THÊM NHÂN VIÊN
-- ==========================
INSERT INTO nhanvien (hoTen, email, phongBan) VALUES
('Nguyen Van An','an@gmail.com','IT'),
('Tran Thi Binh','binh@gmail.com','Nhan su'),
('Le Minh Cuong','cuong@gmail.com','Ke toan'),
('Pham Quoc Dung','dung@gmail.com','Kinh doanh'),
('Hoang Thi Lan','lan@gmail.com','Marketing');

-- ==========================
-- THÊM LỊCH HỌP
-- ==========================
INSERT INTO lichhop
(tieuDe, maPhong, gioBatDau, gioKetThuc, noiDung)
VALUES
('Hop Du an Website',1,'2026-07-15 08:00:00','2026-07-15 10:00:00','Bao cao tien do'),
('Hop Ke Hoach Quy 3',2,'2026-07-16 14:00:00','2026-07-16 15:30:00','Lap ke hoach quy'),
('Hop Tong Ket',3,'2026-07-17 09:00:00','2026-07-17 11:00:00','Tong ket thang');

-- ==========================
-- NHÂN VIÊN THAM GIA HỌP
-- ==========================
INSERT INTO thamgiahop(maHop, maNV, vaiTro, trangThaiThamGia) VALUES
(1,1,'Chu tri','accepted'),
(1,2,'Thanh vien','accepted'),
(1,3,'Thanh vien','pending'),

(2,2,'Chu tri','accepted'),
(2,4,'Thanh vien','accepted'),
(2,5,'Thanh vien','declined'),

(3,1,'Thanh vien','pending'),
(3,3,'Chu tri','accepted'),
(3,5,'Thanh vien','accepted');
