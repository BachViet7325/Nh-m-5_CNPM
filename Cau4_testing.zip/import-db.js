const fs = require('fs');
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

async function importDatabase() {
  const connection = await pool.getConnection();
  try {
    const sql = fs.readFileSync('./database.sql', 'utf8');
    const statements = sql.split(';').map(s => s.trim()).filter(s => s && !s.startsWith('--'));
    
    for (const statement of statements) {
      console.log(`Executing: ${statement.substring(0, 50)}...`);
      await connection.query(statement);
    }
    
    console.log('✅ Database imported successfully!');
  } catch (error) {
    console.error('❌ Error importing database:', error.message);
  } finally {
    connection.release();
    await pool.end();
    process.exit(0);
  }
}

importDatabase();
