const express = require('express');
const mysql = require('mysql2/promise');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DB = {
  host: process.env.DB_HOST || '127.0.0.1',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'quanlylichhop'
};
let pool;
const sessions = new Map();
app.use(express.json({ limit: '200kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const clean = (v) => String(v ?? '').trim();
const emailOk = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const hash = (password) => {
  const salt = crypto.randomBytes(16).toString('hex');
  return `${salt}:${crypto.scryptSync(password, salt, 64).toString('hex')}`;
};
const verify = (password, stored) => {
  try {
    const [salt, key] = stored.split(':');
    return crypto.timingSafeEqual(Buffer.from(key, 'hex'), crypto.scryptSync(password, salt, 64));
  } catch { return false; }
};
const normalizeRole = (v) => ({
  'Nhân viên': 'Nhan vien', 'nhân viên': 'Nhan vien', 'Nhan vien': 'Nhan vien',
  'Quản lý': 'Quan ly', 'Quản lí': 'Quan ly', 'quản lý': 'Quan ly', 'quản lí': 'Quan ly', 'Quan ly': 'Quan ly',
  Admin: 'Admin', admin: 'Admin'
}[clean(v)] || clean(v));
const normalizeStatus = (v) => ({
  active: 'active', 'Đang hoạt động': 'active', 'Hoạt động': 'active',
  locked: 'locked', 'Bị khóa': 'locked', 'Khóa': 'locked'
}[clean(v)] || clean(v));
const normalizeRoomStatus = (v) => ({
  available: 'available', busy: 'busy', maintenance: 'maintenance', inactive: 'inactive',
  'Sẵn sàng': 'available', 'Đang sử dụng': 'busy', 'Bảo trì': 'maintenance', 'Ngừng sử dụng': 'inactive'
}[clean(v)] || clean(v));
const q = async (sql, params = []) => (await pool.execute(sql, params))[0];
const fail = (res, status, message) => res.status(status).json({ errors: [message] });
const safeError = (res, error) => { console.error(error); return fail(res, 500, 'Đã xảy ra lỗi hệ thống.'); };

async function init() {
  const conn = await mysql.createConnection({ ...DB, database: undefined, multipleStatements: true });
  await conn.query(`CREATE DATABASE IF NOT EXISTS \`${DB.database}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
  const [tables] = await conn.query('SELECT COUNT(*) n FROM information_schema.tables WHERE table_schema=?', [DB.database]);
  if (!Number(tables[0].n)) await conn.query(fs.readFileSync(path.join(__dirname, 'database.sql'), 'utf8'));
  await conn.end();
  pool = mysql.createPool({ ...DB, connectionLimit: 10 });

  const migrations = [
    "ALTER TABLE phonghop MODIFY sucChua INT NOT NULL",
    "ALTER TABLE phonghop ADD COLUMN trangThai VARCHAR(20) NOT NULL DEFAULT 'available'",
    "ALTER TABLE phonghop ADD COLUMN thietBi TEXT NULL",
    "ALTER TABLE nhanvien MODIFY email VARCHAR(100) NOT NULL",
    "ALTER TABLE nhanvien MODIFY matKhau VARCHAR(255) NULL",
    "ALTER TABLE nhanvien MODIFY vaiTroHeThong VARCHAR(30) NOT NULL DEFAULT 'Nhan vien'",
    "ALTER TABLE nhanvien MODIFY trangThai VARCHAR(20) NOT NULL DEFAULT 'active'",
    "ALTER TABLE lichhop MODIFY trangThai VARCHAR(20) NOT NULL DEFAULT 'scheduled'",
    "ALTER TABLE thamgiahop ADD COLUMN trangThaiThamGia VARCHAR(20) NOT NULL DEFAULT 'pending'",
    "CREATE INDEX idx_lichhop_phong_time ON lichhop(maPhong,gioBatDau,gioKetThuc)",
    "CREATE INDEX idx_lichhop_time ON lichhop(gioBatDau,gioKetThuc)",
    "CREATE INDEX idx_thamgia_nv ON thamgiahop(maNV)"
  ];
  for (const sql of migrations) {
    try { await pool.query(sql); }
    catch (e) { if (!['ER_DUP_FIELDNAME', 'ER_DUP_KEYNAME'].includes(e.code)) console.warn('Schema:', e.message); }
  }
  await pool.query("UPDATE nhanvien SET vaiTroHeThong='Nhan vien' WHERE vaiTroHeThong IN ('Nhân viên','nhân viên')");
  await pool.query("UPDATE nhanvien SET vaiTroHeThong='Quan ly' WHERE vaiTroHeThong IN ('Quản lý','Quản lí','quản lý','quản lí')");
  await pool.query("UPDATE nhanvien SET trangThai='active' WHERE trangThai IN ('Đang hoạt động','Hoạt động')");
  await pool.query("UPDATE nhanvien SET trangThai='locked' WHERE trangThai IN ('Bị khóa','Khóa')");
  await pool.query("UPDATE thamgiahop SET trangThaiThamGia='accepted' WHERE vaiTro='Chu tri'");
  const admin = await q("SELECT maNV,matKhau FROM nhanvien WHERE email='admin@xyz.com'");
  if (!admin.length) await q("INSERT INTO nhanvien(hoTen,email,phongBan,matKhau,vaiTroHeThong,trangThai) VALUES('System Admin','admin@xyz.com','IT',?,'Admin','active')", [hash('Admin@123')]);
  else if (!admin[0].matKhau) await q('UPDATE nhanvien SET matKhau=? WHERE maNV=?', [hash('Admin@123'), admin[0].maNV]);
}

function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/, '');
  const user = sessions.get(token);
  if (!user) return fail(res, 401, 'Bạn chưa đăng nhập hoặc phiên đã hết hạn.');
  req.user = user; req.token = token; next();
}
const roles = (...allowed) => (req, res, next) => allowed.includes(req.user.role) ? next() : fail(res, 403, 'Bạn không có quyền thực hiện chức năng này.');

app.post('/api/auth/register', async (req, res) => {
  const fullName = clean(req.body.fullName), email = clean(req.body.email).toLowerCase();
  const password = String(req.body.password || ''), department = clean(req.body.department);
  if (fullName.length < 2 || !emailOk(email) || password.length < 8 || !department) return fail(res, 400, 'Họ tên, email, phòng ban và mật khẩu từ 8 ký tự là bắt buộc.');
  try {
    const result = await q("INSERT INTO nhanvien(hoTen,email,phongBan,matKhau,vaiTroHeThong,trangThai) VALUES(?,?,?,?, 'Nhan vien','active')", [fullName, email, department, hash(password)]);
    const user = { id: result.insertId, fullName, email, department, role: 'Nhan vien', status: 'active' };
    const token = crypto.randomBytes(32).toString('hex'); sessions.set(token, user);
    res.status(201).json({ user, token, message: 'Đăng ký thành công.' });
  } catch (e) { if (e.code === 'ER_DUP_ENTRY') return fail(res, 409, 'Email đã được sử dụng.'); safeError(res, e); }
});
app.post('/api/auth/login', async (req, res) => {
  try {
    const users = await q('SELECT maNV id,hoTen fullName,email,phongBan department,matKhau,vaiTroHeThong role,trangThai status FROM nhanvien WHERE email=?', [clean(req.body.email).toLowerCase()]);
    const user = users[0];
    if (user) { user.role = normalizeRole(user.role); user.status = normalizeStatus(user.status); }
    if (!user || !verify(String(req.body.password || ''), user.matKhau || '')) return fail(res, 401, 'Email hoặc mật khẩu không đúng.');
    if (user.status !== 'active') return fail(res, 403, 'Tài khoản đang bị khóa.');
    delete user.matKhau;
    const token = crypto.randomBytes(32).toString('hex'); sessions.set(token, user);
    res.json({ user, token, message: 'Đăng nhập thành công.' });
  } catch (e) { safeError(res, e); }
});
app.get('/api/auth/me', auth, (req, res) => res.json({ user: req.user }));
app.post('/api/auth/logout', auth, (req, res) => { sessions.delete(req.token); res.json({ message: 'Đã đăng xuất.' }); });

app.get('/api/profile', auth, (req, res) => res.json({ user: req.user }));
app.put('/api/profile', auth, async (req, res) => {
  const fullName = clean(req.body.fullName), email = clean(req.body.email).toLowerCase(), department = clean(req.body.department);
  if (fullName.length < 2 || !emailOk(email) || !department) return fail(res, 400, 'Thông tin cá nhân không hợp lệ.');
  try {
    await q('UPDATE nhanvien SET hoTen=?,email=?,phongBan=? WHERE maNV=?', [fullName, email, department, req.user.id]);
    Object.assign(req.user, { fullName, email, department }); sessions.set(req.token, req.user);
    res.json({ message: 'Đã cập nhật thông tin cá nhân.', user: req.user });
  } catch (e) { if (e.code === 'ER_DUP_ENTRY') return fail(res, 409, 'Email đã tồn tại.'); safeError(res, e); }
});
app.put('/api/profile/password', auth, async (req, res) => {
  const currentPassword = String(req.body.currentPassword || ''), newPassword = String(req.body.newPassword || '');
  if (newPassword.length < 8) return fail(res, 400, 'Mật khẩu mới phải có ít nhất 8 ký tự.');
  try {
    const row = (await q('SELECT matKhau FROM nhanvien WHERE maNV=?', [req.user.id]))[0];
    if (!row || !verify(currentPassword, row.matKhau || '')) return fail(res, 400, 'Mật khẩu hiện tại không đúng.');
    await q('UPDATE nhanvien SET matKhau=? WHERE maNV=?', [hash(newPassword), req.user.id]);
    res.json({ message: 'Đổi mật khẩu thành công.' });
  } catch (e) { safeError(res, e); }
});

app.get('/api/users', auth, async (req, res) => {
  try {
    let sql = "SELECT maNV id,hoTen fullName,email,phongBan,CASE WHEN vaiTroHeThong IN ('Nhân viên','Nhan vien') THEN 'Nhan vien' WHEN vaiTroHeThong IN ('Quản lý','Quản lí','Quan ly') THEN 'Quan ly' ELSE vaiTroHeThong END role,CASE WHEN trangThai IN ('Đang hoạt động','Hoạt động','active') THEN 'active' ELSE 'locked' END status FROM nhanvien";
    const params = [];
    if (req.user.role === 'Nhan vien') sql += " WHERE trangThai IN ('active','Đang hoạt động','Hoạt động')";
    else if (req.user.role === 'Quan ly') { sql += ' WHERE phongBan=?'; params.push(req.user.department); }
    sql += ' ORDER BY hoTen';
    res.json(await q(sql, params));
  } catch (e) { safeError(res, e); }
});
app.post('/api/users', auth, roles('Admin'), async (req, res) => {
  const fullName = clean(req.body.fullName), email = clean(req.body.email).toLowerCase(), department = clean(req.body.phongBan || req.body.department);
  const password = String(req.body.password || 'Temp@123'), role = normalizeRole(req.body.role || 'Nhan vien'), status = normalizeStatus(req.body.status || 'active');
  if (fullName.length < 2 || !emailOk(email) || !department || password.length < 8 || !['Nhan vien','Quan ly','Admin'].includes(role) || !['active','locked'].includes(status)) return fail(res, 400, 'Dữ liệu người dùng không hợp lệ.');
  try { const r = await q('INSERT INTO nhanvien(hoTen,email,phongBan,matKhau,vaiTroHeThong,trangThai) VALUES(?,?,?,?,?,?)', [fullName,email,department,hash(password),role,status]); res.status(201).json({ id:r.insertId, message:'Đã tạo tài khoản.' }); }
  catch (e) { if (e.code === 'ER_DUP_ENTRY') return fail(res,409,'Email đã tồn tại.'); safeError(res,e); }
});
app.put('/api/users/:id', auth, roles('Admin'), async (req,res) => {
  try {
    const current = (await q('SELECT * FROM nhanvien WHERE maNV=?',[req.params.id]))[0]; if(!current) return fail(res,404,'Không tìm thấy người dùng.');
    const fullName=clean(req.body.fullName||current.hoTen), email=clean(req.body.email||current.email).toLowerCase(), department=clean(req.body.phongBan||req.body.department||current.phongBan);
    const role=normalizeRole(req.body.role||current.vaiTroHeThong), status=normalizeStatus(req.body.status||current.trangThai);
    if(fullName.length<2||!emailOk(email)||!department||!['Nhan vien','Quan ly','Admin'].includes(role)||!['active','locked'].includes(status)) return fail(res,400,'Dữ liệu người dùng không hợp lệ.');
    if(Number(req.params.id)===req.user.id&&status==='locked') return fail(res,400,'Không thể tự khóa tài khoản đang đăng nhập.');
    await q('UPDATE nhanvien SET hoTen=?,email=?,phongBan=?,vaiTroHeThong=?,trangThai=? WHERE maNV=?',[fullName,email,department,role,status,req.params.id]);
    if(Number(req.params.id)===req.user.id){Object.assign(req.user,{fullName,email,department,role,status});sessions.set(req.token,req.user);}
    res.json({message:'Đã cập nhật người dùng.',user:Number(req.params.id)===req.user.id?req.user:undefined});
  } catch(e){if(e.code==='ER_DUP_ENTRY')return fail(res,409,'Email đã tồn tại.');safeError(res,e);}
});
app.delete('/api/users/:id', auth, roles('Admin'), async (req,res)=>{
  if(Number(req.params.id)===req.user.id) return fail(res,400,'Không thể tự khóa tài khoản đang đăng nhập.');
  try { const r=await q("UPDATE nhanvien SET trangThai='locked' WHERE maNV=?",[req.params.id]); if(!r.affectedRows)return fail(res,404,'Không tìm thấy người dùng.'); res.json({message:'Đã khóa tài khoản.'}); } catch(e){safeError(res,e);}
});

app.get('/api/rooms', auth, async (req,res)=>{
  try { res.json(await q(`SELECT p.maPhong id,p.tenPhong name,p.viTri location,p.sucChua capacity,p.trangThai status,p.thietBi equipment,COUNT(l.maHop) meetingCount FROM phonghop p LEFT JOIN lichhop l ON l.maPhong=p.maPhong AND l.trangThai<>'cancelled' GROUP BY p.maPhong ORDER BY p.tenPhong`)); } catch(e){safeError(res,e);}
});
app.post('/api/rooms', auth, roles('Quan ly','Admin'), async(req,res)=>{
  const name=clean(req.body.name), location=clean(req.body.location), capacity=Number(req.body.capacity), status=normalizeRoomStatus(req.body.status||'available'), equipment=clean(req.body.equipment);
  if(!name||!Number.isInteger(capacity)||capacity<=0||!['available','busy','maintenance','inactive'].includes(status))return fail(res,400,'Dữ liệu phòng không hợp lệ.');
  try{const r=await q('INSERT INTO phonghop(tenPhong,viTri,sucChua,trangThai,thietBi) VALUES(?,?,?,?,?)',[name,location,capacity,status,equipment]);res.status(201).json({id:r.insertId,message:'Đã thêm phòng.'});}catch(e){safeError(res,e);}
});
app.put('/api/rooms/:id', auth, roles('Quan ly','Admin'), async(req,res)=>{
  const name=clean(req.body.name), location=clean(req.body.location), capacity=Number(req.body.capacity), status=normalizeRoomStatus(req.body.status||'available'), equipment=clean(req.body.equipment);
  if(!name||!Number.isInteger(capacity)||capacity<=0||!['available','busy','maintenance','inactive'].includes(status))return fail(res,400,'Dữ liệu phòng không hợp lệ.');
  try{const r=await q('UPDATE phonghop SET tenPhong=?,viTri=?,sucChua=?,trangThai=?,thietBi=? WHERE maPhong=?',[name,location,capacity,status,equipment,req.params.id]);if(!r.affectedRows)return fail(res,404,'Không tìm thấy phòng.');res.json({message:'Đã cập nhật phòng.'});}catch(e){safeError(res,e);}
});
app.delete('/api/rooms/:id', auth, roles('Quan ly','Admin'), async(req,res)=>{
  try{const r=await q('DELETE FROM phonghop WHERE maPhong=?',[req.params.id]);if(!r.affectedRows)return fail(res,404,'Không tìm thấy phòng.');res.json({message:'Đã xóa phòng.'});}catch(e){if(e.code==='ER_ROW_IS_REFERENCED_2')return fail(res,409,'Phòng đã có lịch sử họp, hãy chuyển trạng thái thành Ngừng sử dụng thay vì xóa.');safeError(res,e);}
});
app.get('/api/rooms/:id/history', auth, roles('Quan ly','Admin'), async(req,res)=>{
  try{res.json(await q(`SELECT l.maHop id,l.tieuDe title,DATE_FORMAT(l.gioBatDau,'%Y-%m-%d') meetingDate,TIME_FORMAT(l.gioBatDau,'%H:%i') startTime,TIME_FORMAT(l.gioKetThuc,'%H:%i') endTime,ROUND(TIMESTAMPDIFF(MINUTE,l.gioBatDau,l.gioKetThuc)/60,2) hours,l.trangThai status,n.hoTen organizerName FROM lichhop l JOIN thamgiahop t ON t.maHop=l.maHop AND t.vaiTro='Chu tri' JOIN nhanvien n ON n.maNV=t.maNV WHERE l.maPhong=? ORDER BY l.gioBatDau DESC`,[req.params.id]));}catch(e){safeError(res,e);}
});
app.get('/api/rooms/:id/available-slots', auth, roles('Quan ly','Admin'), async(req,res)=>{
  const date=clean(req.query.date); if(!/^\d{4}-\d{2}-\d{2}$/.test(date))return fail(res,400,'Ngày không hợp lệ.');
  try{
    const busy=await q("SELECT TIME_FORMAT(gioBatDau,'%H:%i') start,TIME_FORMAT(gioKetThuc,'%H:%i') end FROM lichhop WHERE maPhong=? AND DATE(gioBatDau)=? AND trangThai<>'cancelled' ORDER BY gioBatDau",[req.params.id,date]);
    const slots=[]; let cursor='08:00';
    for(const b of busy){if(cursor<b.start)slots.push({start:cursor,end:b.start});if(cursor<b.end)cursor=b.end;}
    if(cursor<'18:00')slots.push({start:cursor,end:'18:00'});
    res.json({date,busy,available:slots});
  }catch(e){safeError(res,e);}
});

function meetingData(body){return{title:clean(body.title),date:clean(body.meetingDate),start:clean(body.startTime),end:clean(body.endTime),room:Number(body.roomId),participants:[...new Set((body.participantIds||[]).map(Number).filter(Number.isInteger))],content:clean(body.content)}}
function validateMeeting(d){const errors=[];if(!d.title||d.title.length>100)errors.push('Tên cuộc họp từ 1 đến 100 ký tự.');if(!/^\d{4}-\d{2}-\d{2}$/.test(d.date))errors.push('Ngày họp không hợp lệ.');if(!/^\d{2}:\d{2}$/.test(d.start)||!/^\d{2}:\d{2}$/.test(d.end)||d.start>=d.end)errors.push('Thời gian họp không hợp lệ.');if(!Number.isInteger(d.room)||d.room<=0)errors.push('Phòng họp không hợp lệ.');if(d.content.length>500)errors.push('Nội dung tối đa 500 ký tự.');return errors;}
async function validateResources(d, organizer){
  const ids=[...new Set([organizer,...d.participants])];
  const room=(await q('SELECT sucChua,trangThai FROM phonghop WHERE maPhong=?',[d.room]))[0];
  if(!room)return ['Không tìm thấy phòng.'];
  if(['maintenance','inactive'].includes(room.trangThai))return ['Phòng đang bảo trì hoặc ngừng sử dụng.'];
  if(ids.length>room.sucChua)return [`Phòng chỉ chứa tối đa ${room.sucChua} người.`];
  const placeholders=ids.map(()=>'?').join(',');
  const users=await q(`SELECT maNV FROM nhanvien WHERE trangThai='active' AND maNV IN (${placeholders})`,ids);
  return users.length===ids.length?[]:['Có người tham gia không tồn tại hoặc bị khóa.'];
}
async function conflicts(d, organizer, exclude=0){
  const start=`${d.date} ${d.start}:00`,end=`${d.date} ${d.end}:00`,errors=[];
  const room=await q("SELECT COUNT(*) n FROM lichhop WHERE maPhong=? AND maHop<>? AND trangThai<>'cancelled' AND gioBatDau<? AND gioKetThuc>?",[d.room,exclude,end,start]);
  if(room[0].n)errors.push('Phòng họp đã bị trùng lịch.');
  for(const id of [...new Set([organizer,...d.participants])]){
    const rows=await q("SELECT COUNT(*) n FROM thamgiahop t JOIN lichhop l ON l.maHop=t.maHop WHERE t.maNV=? AND l.maHop<>? AND l.trangThai<>'cancelled' AND t.trangThaiThamGia<>'declined' AND l.gioBatDau<? AND l.gioKetThuc>?",[id,exclude,end,start]);
    if(rows[0].n)errors.push(`Người dùng #${id} bị trùng lịch.`);
  }
  return errors;
}
async function owner(id,user){const rows=await q("SELECT maNV FROM thamgiahop WHERE maHop=? AND vaiTro='Chu tri'",[id]);return user.role==='Admin'||(rows[0]&&rows[0].maNV===user.id);}

app.get('/api/meetings', auth, async(req,res)=>{
  try{
    const where=['1=1'],params=[];
    if(req.query.fromDate){where.push('DATE(l.gioBatDau)>=?');params.push(req.query.fromDate);}
    if(req.query.toDate){where.push('DATE(l.gioBatDau)<=?');params.push(req.query.toDate);}
    if(req.query.status){where.push("(CASE WHEN l.trangThai='scheduled' AND l.gioKetThuc<NOW() THEN 'completed' ELSE l.trangThai END)=?");params.push(req.query.status);}
    if(req.query.roomId){where.push('l.maPhong=?');params.push(Number(req.query.roomId));}
    if(req.query.organizerId){where.push('o.maNV=?');params.push(Number(req.query.organizerId));}
    if(req.user.role==='Nhan vien'){where.push('EXISTS(SELECT 1 FROM thamgiahop z WHERE z.maHop=l.maHop AND z.maNV=?)');params.push(req.user.id);}
    else if(req.user.role==='Quan ly'){where.push('EXISTS(SELECT 1 FROM thamgiahop z JOIN nhanvien n2 ON n2.maNV=z.maNV WHERE z.maHop=l.maHop AND n2.phongBan=?)');params.push(req.user.department);}
    const rows=await q(`SELECT l.maHop id,l.tieuDe title,DATE_FORMAT(l.gioBatDau,'%Y-%m-%d') meetingDate,TIME_FORMAT(l.gioBatDau,'%H:%i') startTime,TIME_FORMAT(l.gioKetThuc,'%H:%i') endTime,l.maPhong roomId,p.tenPhong roomName,l.noiDung content,CASE WHEN l.trangThai='scheduled' AND l.gioKetThuc<NOW() THEN 'completed' ELSE l.trangThai END status,o.maNV organizerId,o.hoTen organizerName FROM lichhop l JOIN phonghop p ON p.maPhong=l.maPhong JOIN thamgiahop tc ON tc.maHop=l.maHop AND tc.vaiTro='Chu tri' JOIN nhanvien o ON o.maNV=tc.maNV WHERE ${where.join(' AND ')} ORDER BY l.gioBatDau`,params);
    if(rows.length){const ids=rows.map(x=>x.id),ph=ids.map(()=>'?').join(',');const participants=await q(`SELECT t.maHop meetingId,n.maNV id,n.hoTen fullName,t.vaiTro meetingRole,t.trangThaiThamGia responseStatus FROM thamgiahop t JOIN nhanvien n ON n.maNV=t.maNV WHERE t.maHop IN (${ph})`,ids);for(const row of rows){row.participants=participants.filter(x=>x.meetingId===row.id);const mine=row.participants.find(x=>x.id===req.user.id);row.myResponse=mine?.responseStatus||null;}}
    res.json(rows);
  }catch(e){safeError(res,e);}
});
app.post('/api/meetings/check', auth, async(req,res)=>{
  try{const d=meetingData(req.body),errors=validateMeeting(d);if(errors.length)return res.status(400).json({ok:false,errors});const resourceErrors=await validateResources(d,req.user.id);if(resourceErrors.length)return res.status(400).json({ok:false,errors:resourceErrors});const conflictErrors=await conflicts(d,req.user.id,Number(req.body.id||0));if(conflictErrors.length)return res.status(409).json({ok:false,errors:conflictErrors});res.json({ok:true,message:'Lịch hợp lệ.'});}catch(e){safeError(res,e);}
});
app.post('/api/meetings', auth, async(req,res)=>{
  const d=meetingData(req.body),errors=validateMeeting(d);if(errors.length)return res.status(400).json({errors});
  try{const resourceErrors=await validateResources(d,req.user.id);if(resourceErrors.length)return res.status(400).json({errors:resourceErrors});const conflictErrors=await conflicts(d,req.user.id);if(conflictErrors.length)return res.status(409).json({errors:conflictErrors});const conn=await pool.getConnection();try{await conn.beginTransaction();const [r]=await conn.execute("INSERT INTO lichhop(tieuDe,maPhong,gioBatDau,gioKetThuc,noiDung,trangThai) VALUES(?,?,?,?,?,'scheduled')",[d.title,d.room,`${d.date} ${d.start}:00`,`${d.date} ${d.end}:00`,d.content]);await conn.execute("INSERT INTO thamgiahop(maHop,maNV,vaiTro,trangThaiThamGia) VALUES(?,?,'Chu tri','accepted')",[r.insertId,req.user.id]);for(const id of d.participants)if(id!==req.user.id)await conn.execute("INSERT INTO thamgiahop(maHop,maNV,vaiTro,trangThaiThamGia) VALUES(?,?,'Thanh vien','pending')",[r.insertId,id]);await conn.commit();res.status(201).json({id:r.insertId,message:'Đã tạo lịch họp và gửi lời mời.'});}catch(e){await conn.rollback();throw e;}finally{conn.release();}}catch(e){safeError(res,e);}
});
app.put('/api/meetings/:id', auth, async(req,res)=>{
  try{if(!await owner(req.params.id,req.user))return fail(res,403,'Chỉ chủ trì hoặc Admin được sửa lịch.');const d=meetingData(req.body),errors=validateMeeting(d);if(errors.length)return res.status(400).json({errors});const organizer=(await q("SELECT maNV FROM thamgiahop WHERE maHop=? AND vaiTro='Chu tri'",[req.params.id]))[0]?.maNV;if(!organizer)return fail(res,404,'Không tìm thấy cuộc họp.');const resourceErrors=await validateResources(d,organizer);if(resourceErrors.length)return res.status(400).json({errors:resourceErrors});const conflictErrors=await conflicts(d,organizer,Number(req.params.id));if(conflictErrors.length)return res.status(409).json({errors:conflictErrors});const conn=await pool.getConnection();try{await conn.beginTransaction();await conn.execute('UPDATE lichhop SET tieuDe=?,maPhong=?,gioBatDau=?,gioKetThuc=?,noiDung=? WHERE maHop=?',[d.title,d.room,`${d.date} ${d.start}:00`,`${d.date} ${d.end}:00`,d.content,req.params.id]);await conn.execute("DELETE FROM thamgiahop WHERE maHop=? AND vaiTro<>'Chu tri'",[req.params.id]);for(const id of d.participants)if(id!==organizer)await conn.execute("INSERT INTO thamgiahop(maHop,maNV,vaiTro,trangThaiThamGia) VALUES(?,?,'Thanh vien','pending')",[req.params.id,id]);await conn.commit();res.json({message:'Đã cập nhật lịch họp và gửi lại lời mời.'});}catch(e){await conn.rollback();throw e;}finally{conn.release();}}catch(e){safeError(res,e);}
});
app.put('/api/meetings/:id/response', auth, async(req,res)=>{
  const response=clean(req.body.response);if(!['accepted','declined'].includes(response))return fail(res,400,'Phản hồi không hợp lệ.');
  try{const r=await q("UPDATE thamgiahop SET trangThaiThamGia=? WHERE maHop=? AND maNV=? AND vaiTro<>'Chu tri'",[response,req.params.id,req.user.id]);if(!r.affectedRows)return fail(res,404,'Bạn không có lời mời cho cuộc họp này.');res.json({message:response==='accepted'?'Đã xác nhận tham gia.':'Đã từ chối tham gia.'});}catch(e){safeError(res,e);}
});
app.put('/api/meetings/:id/cancel', auth, async(req,res)=>{try{if(!await owner(req.params.id,req.user))return fail(res,403,'Chỉ chủ trì hoặc Admin được hủy lịch.');const r=await q("UPDATE lichhop SET trangThai='cancelled' WHERE maHop=?",[req.params.id]);if(!r.affectedRows)return fail(res,404,'Không tìm thấy cuộc họp.');res.json({message:'Đã hủy cuộc họp.'});}catch(e){safeError(res,e);}});
app.delete('/api/meetings/:id', auth, roles('Admin'), async(req,res)=>{try{const r=await q('DELETE FROM lichhop WHERE maHop=?',[req.params.id]);if(!r.affectedRows)return fail(res,404,'Không tìm thấy cuộc họp.');res.json({message:'Đã xóa cuộc họp.'});}catch(e){safeError(res,e);}});

app.get('/api/admin/stats', auth, roles('Admin'), async(req,res)=>{
  try{
    const conditions=[],params=[];if(req.query.fromDate){conditions.push('DATE(l.gioBatDau)>=?');params.push(req.query.fromDate);}if(req.query.toDate){conditions.push('DATE(l.gioBatDau)<=?');params.push(req.query.toDate);}const where=conditions.length?' AND '+conditions.join(' AND '):'';
    const [users,rooms,summary,monthly,roomUsage,organizers]=await Promise.all([
      q("SELECT COUNT(*) total,SUM(trangThai='active') active FROM nhanvien"),
      q("SELECT COUNT(*) total,SUM(trangThai='available') available FROM phonghop"),
      q(`SELECT COUNT(*) total,SUM(l.trangThai='scheduled' AND l.gioKetThuc>=NOW()) scheduled,SUM(l.trangThai='cancelled') cancelled,SUM(l.trangThai<>'cancelled' AND l.gioKetThuc<NOW()) completed FROM lichhop l WHERE 1=1${where}`,params),
      q(`SELECT DATE_FORMAT(l.gioBatDau,'%m/%Y') month,COUNT(*) count FROM lichhop l WHERE 1=1${where} GROUP BY YEAR(l.gioBatDau),MONTH(l.gioBatDau) ORDER BY MIN(l.gioBatDau)`,params),
      q(`SELECT ph.maPhong id,ph.tenPhong name,COUNT(l.maHop) count,ROUND(COALESCE(SUM(TIMESTAMPDIFF(MINUTE,l.gioBatDau,l.gioKetThuc)),0)/60,1) hours FROM phonghop ph LEFT JOIN lichhop l ON l.maPhong=ph.maPhong AND l.trangThai<>'cancelled'${where.replaceAll('l.','l.')} GROUP BY ph.maPhong ORDER BY hours DESC`,params),
      q(`SELECT n.hoTen fullName,COUNT(*) count FROM thamgiahop t JOIN nhanvien n ON n.maNV=t.maNV JOIN lichhop l ON l.maHop=t.maHop WHERE t.vaiTro='Chu tri' AND l.trangThai<>'cancelled'${where} GROUP BY n.maNV ORDER BY count DESC LIMIT 5`,params)
    ]);
    res.json({totalUsers:users[0].total,activeUsers:Number(users[0].active||0),totalRooms:rooms[0].total,availableRooms:Number(rooms[0].available||0),totalMeetings:summary[0].total,scheduledMeetings:Number(summary[0].scheduled||0),completedMeetings:Number(summary[0].completed||0),cancelledMeetings:Number(summary[0].cancelled||0),monthly,roomUsage,organizers});
  }catch(e){safeError(res,e);}
});

init().then(()=>app.listen(PORT,()=>console.log(`🚀 http://localhost:${PORT}\n🔐 Admin: admin@xyz.com / Admin@123`))).catch(e=>{console.error('❌ Không thể khởi tạo database:',e.code,e.message);console.error(DB);});
